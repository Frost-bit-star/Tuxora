# Tuxora welcome for desktop (X) terminals. TermuxActivity sessions already
# show the welcome via the termux login motd and have TERMUX_VERSION set,
# so skip there to avoid printing it twice.
if [ -z "$TERMUX_VERSION" ]; then
    [ -r "$PREFIX/etc/motd" ] && cat "$PREFIX/etc/motd"
fi

export MPD_HOST="${MPD_HOST:-127.0.0.1}"
