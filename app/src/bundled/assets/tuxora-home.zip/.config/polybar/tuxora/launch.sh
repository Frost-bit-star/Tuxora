#!/data/data/com.termux/files/usr/bin/bash

# Terminate already running bar instances
pkill -f "polybar main" 2>/dev/null || killall -q polybar 2>/dev/null

# Wait (bounded) until the processes have been shut down
for _i in $(seq 1 20); do
    pgrep -f "polybar main" >/dev/null || break
    sleep 0.2
done

# Force-kill if it is still alive, so we never block the session
pgrep -f "polybar main" >/dev/null && pkill -9 -f "polybar main" 2>/dev/null

# Launch the bar (keep a log so module/script errors are diagnosable)
polybar main -c "$HOME"/.config/polybar/tuxora/config.ini >"$HOME/polybar.log" 2>&1 &
