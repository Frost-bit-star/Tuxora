#!/usr/bin/env bash

# Terminate already running bar instances
pkill -x polybar 2>/dev/null || killall -q polybar 2>/dev/null

# Wait (bounded) until the processes have been shut down
for _i in $(seq 1 20); do
    pgrep -x polybar >/dev/null || break
    sleep 0.2
done

# Force-kill if it is still alive, so we never block the session
pgrep -x polybar >/dev/null && pkill -9 -x polybar 2>/dev/null

# Launch the bar
polybar main -c "$HOME"/.config/polybar/default/config.ini &
