#!/data/data/com.termux/files/usr/bin/bash

# Launch the bar
STYLE="tuxora"

bash "$HOME"/.config/polybar/"$STYLE"/launch.sh
