#!/usr/bin/env bash

# Launch the bar
STYLE="tuxora"

bash "$HOME"/.config/polybar/"$STYLE"/launch.sh
